# 🔧 Guia de Solução: Falha na Autenticação OAuth2

## ⛔ Problema
**Erro**: O servidor recusou as credenciais durante a autenticação OAuth2.

## 🎯 Soluções Implementadas

### 1. **Remoção Automática de Espaços**
O plugin agora remove automaticamente espaços em branco da senha antes de validar. Isso resolve o problema mais comum de falha de autenticação.

**Arquivos modificados:**
- `library/WPOAuth2/Storage/Wordpressdb.php` - Função `checkPassword()`
- `library/WPOAuth2/Request.php` - Processamento do header Authorization

### 2. **Logs de Debug Ativados**
Para diagnosticar problemas, ative o modo debug do WordPress:

**No arquivo `wp-config.php`, adicione:**
```php
define('WP_DEBUG', true);
define('WP_DEBUG_LOG', true);
define('WP_DEBUG_DISPLAY', false);
```

**Os logs serão salvos em:** `wp-content/debug.log`

**Você verá informações como:**
```
[ACI OAuth] Authorization header recebido: Basic YWRtaW46...
[ACI OAuth] Usuário extraído: admin
[ACI OAuth] Senha tem 12 caracteres
[ACI OAuth] Tentativa de login para usuário: admin
[ACI OAuth] Autenticação bem-sucedida para: admin
```

## 🔍 Diagnóstico de Problemas

### Problema 1: Nginx/Easypanel Bloqueando o Header Authorization

**Sintoma:** O header Authorization não chega ao PHP.

**Solução para Nginx:**
Adicione ao arquivo de configuração do Nginx:

```nginx
location / {
    # Passa o header Authorization para o PHP
    fastcgi_pass_header Authorization;
    
    # Ou use esta alternativa:
    proxy_set_header Authorization $http_authorization;
    proxy_pass_header Authorization;
}
```

**Solução para Apache (.htaccess):**
```apache
RewriteEngine On
RewriteRule .* - [E=HTTP_AUTHORIZATION:%{HTTP:Authorization}]
```

**Solução para Easypanel:**
1. Acesse as configurações do seu aplicativo
2. Vá em "Environment Variables" ou "Nginx Config"
3. Adicione a configuração acima

### Problema 2: Senha de Aplicativo vs Senha Real

**WordPress pode ter dois tipos de senhas:**
1. **Senha de Login** - A senha que você usa para fazer login no painel
2. **Senha de Aplicativo** - Senhas específicas para aplicativos externos

**Para testar:**
1. Primeiro, tente com a **senha de login real**
2. Se não funcionar, crie uma **senha de aplicativo**:
   - Vá em: Usuários → Seu Perfil
   - Role até "Senhas de Aplicativo"
   - Crie uma nova senha
   - Use essa senha no OAuth2

### Problema 3: Espaços na Senha

**✅ JÁ RESOLVIDO!** O plugin agora remove espaços automaticamente.

Se você copiou e colou a senha, pode ter incluído espaços extras. O plugin agora trata isso automaticamente.

## 🧪 Como Testar

### Teste 1: Verificar se o Header Chega ao Servidor

Crie um arquivo `test-auth.php` na raiz do WordPress:

```php
<?php
header('Content-Type: application/json');

$headers = getallheaders();
$auth = isset($headers['Authorization']) ? $headers['Authorization'] : 'NÃO ENCONTRADO';

echo json_encode([
    'authorization_header' => $auth,
    'all_headers' => $headers,
    'server_vars' => [
        'HTTP_AUTHORIZATION' => $_SERVER['HTTP_AUTHORIZATION'] ?? 'não definido',
        'PHP_AUTH_USER' => $_SERVER['PHP_AUTH_USER'] ?? 'não definido',
        'PHP_AUTH_PW' => isset($_SERVER['PHP_AUTH_PW']) ? 'DEFINIDO' : 'não definido'
    ]
], JSON_PRETTY_PRINT);
```

**Teste via cURL:**
```bash
curl -H "Authorization: Basic $(echo -n 'usuario:senha' | base64)" \
     https://seu-site.com/test-auth.php
```

**Resultado esperado:**
```json
{
    "authorization_header": "Basic dXN1YXJpbzpzZW5oYQ==",
    "server_vars": {
        "HTTP_AUTHORIZATION": "Basic dXN1YXJpbzpzZW5oYQ==",
        "PHP_AUTH_USER": "usuario",
        "PHP_AUTH_PW": "DEFINIDO"
    }
}
```

### Teste 2: Autenticação OAuth2

**Endpoint de Token:**
```
POST https://seu-site.com/oauth/token
```

**Headers:**
```
Authorization: Basic [base64(client_id:client_secret)]
Content-Type: application/x-www-form-urlencoded
```

**Body:**
```
grant_type=password
username=seu_usuario
password=sua_senha
```

**Exemplo com cURL:**
```bash
curl -X POST https://seu-site.com/oauth/token \
  -H "Authorization: Basic $(echo -n 'client_id:client_secret' | base64)" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=password&username=admin&password=sua_senha"
```

## 📋 Checklist de Resolução

- [ ] Ativar WP_DEBUG e verificar logs
- [ ] Remover espaços da senha (já feito automaticamente)
- [ ] Verificar se o header Authorization chega ao servidor (test-auth.php)
- [ ] Se usar Nginx/Easypanel, configurar para passar o header Authorization
- [ ] Testar com senha de login real
- [ ] Se necessário, criar e testar com senha de aplicativo
- [ ] Verificar se o client_id e client_secret estão corretos
- [ ] Verificar se o grant_type está habilitado nas configurações do cliente OAuth

## 🆘 Ainda com Problemas?

1. **Verifique os logs:** `wp-content/debug.log`
2. **Teste o endpoint:** Use o arquivo `test-auth.php`
3. **Verifique a configuração do servidor:** Nginx/Apache/Easypanel
4. **Teste com diferentes senhas:** Login real vs Senha de aplicativo

## 📞 Suporte

**Desenvolvido por:** Automações Comerciais Integradas  
**Email:** contato@automacoescomerciais.com.br  
**Site:** https://aci.automacoescomerciais.com.br

---

**Última atualização:** 2026-01-11
