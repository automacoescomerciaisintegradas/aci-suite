# Servidor Completo plugin  OAuth2 para WordPress

Este plugin fornece um servidor OAuth2 completo para WordPress, permitindo que você gerencie autorizações de usuário e forneça tokens de acesso para aplicações externas.

## Recursos

- Implementação completa do protocolo OAuth2
- Suporte a múltiplos tipos de concessão (grant types):
  - Authorization Code
  - Client Credentials
  - Resource Owner Password Credentials
  - Refresh Token
- Integração com o sistema de usuários do WordPress
- Suporte a tokens JWT
- Endpoints para introspecção e revogação de tokens
- Configurações de escopo personalizáveis
- Interface de administração para gerenciamento de clientes

## Instalação

1. Faça upload do plugin para o diretório `/wp-content/plugins/`
2. Ative o plugin através do menu "Plugins" no WordPress
3. Configure as opções do servidor OAuth2 na página de administração

## Configuração

Após ativar o plugin, você pode configurar os seguintes parâmetros:

- Tamanho do client ID
- Tipos de concessão habilitados
- Tempo de vida dos tokens
- Tamanho dos tokens
- Configurações de segurança PKCE
- Chaves de criptografia JWT

## Endpoints Disponíveis

O servidor OAuth2 fornece os seguintes endpoints:

- `POST /oauth/token` - Para obter tokens de acesso
- `GET /oauth/authorize` - Para autorização de clientes
- `GET /oauth/me` - Para informações do usuário autenticado
- `POST /oauth/revoke` - Para revogar tokens
- `GET /.well-known/openid-configuration` - Para configurações OpenID Connect
- `GET /.well-known/keys` - Para chaves públicas JWT

## Exemplos de Uso

### Obtendo um token de acesso com Authorization Code

1. Redirecione o usuário para:
   ```
   /oauth/authorize?response_type=code&client_id={client_id}&redirect_uri={redirect_uri}&scope={scopes}
   ```

2. Após a autorização, o usuário será redirecionado para seu `redirect_uri` com um `authorization_code`.

3. Troque o código por um token de acesso:
   ```
   POST /oauth/token
   Content-Type: application/x-www-form-urlencoded
   
   grant_type=authorization_code&code={authorization_code}&client_id={client_id}&client_secret={client_secret}&redirect_uri={redirect_uri}
   ```

### Usando o token de acesso

Para acessar recursos protegidos, inclua o token no cabeçalho de autorização:
```
Authorization: Bearer {access_token}
```

## Segurança

- O plugin implementa práticas de segurança recomendadas para OAuth2
- Todos os tokens são gerados com alta entropia
- Suporte a PKCE para aplicativos móveis e SPA
- Verificação de escopos e permissões
- Proteção contra CSRF em requisições de autorização

## Personalização

Você pode estender o plugin usando os seguintes hooks:

### Filtros

- `wo_scopes` - Modificar escopos disponíveis
- `wo_default_scope` - Definir escopo padrão
- `wo_www_realm` - Modificar realm WWW
- `wo_token_param_name` - Modificar nome do parâmetro de token
- `wo_server_keys` - Modificar localização das chaves do servidor

### Ações

- `wo_before_api` - Antes de qualquer requisição à API
- `wo_before_token_method` - Antes do método de token
- `wo_before_authorize_method` - Antes do método de autorização
- `wo_set_access_token` - Após definir token de acesso
- `wo_login_check` - Após verificação de login

## Solução de Problemas

### ⛔ Falha na Autenticação

Se você está recebendo o erro **"O servidor recusou as credenciais"**, consulte o guia completo de solução:

📖 **[SOLUCAO-AUTENTICACAO.md](SOLUCAO-AUTENTICACAO.md)**

Este guia cobre:
- Remoção automática de espaços da senha
- Configuração do Nginx/Easypanel para passar o header Authorization
- Diferença entre senha de login e senha de aplicativo
- Logs de debug para diagnóstico
- Arquivo de teste para verificar se o header está chegando ao servidor

#### Teste Rápido

1. **Ative o modo debug** no `wp-config.php`:
   ```php
   define('WP_DEBUG', true);
   define('WP_DEBUG_LOG', true);
   define('WP_DEBUG_DISPLAY', false);
   ```

2. **Faça upload do arquivo de teste** `test-auth-header.php` para a raiz do WordPress

3. **Teste via cURL**:
   ```bash
   curl -H "Authorization: Basic $(echo -n 'usuario:senha' | base64)" \
        https://seu-site.com/test-auth-header.php
   ```

4. **Verifique os logs** em `wp-content/debug.log`

### Outros Problemas Comuns

Se encontrar outros problemas, verifique:

- Se as regras de reescrita do WordPress estão funcionando (tente atualizar links permanentes)
- Se as tabelas do banco de dados foram criadas corretamente
- Se os certificados de criptografia foram gerados
- Os logs de erro do WordPress

## Desenvolvido por

Automações Comerciais Integradas! ⚙️ (Canal/Grupo) - contato@automacoescomerciais.com.br