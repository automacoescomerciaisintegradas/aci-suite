<?php
if (!defined('ABSPATH')) {
    exit; // Protege contra acesso direto ao arquivo
}

class WebPush {

    private $plugin_name;
    private $version;

    public function __construct($plugin_name, $version) {
        $this->plugin_name = $plugin_name;
        $this->version = $version;

        // Hooks do WordPress
        add_action('init', array($this, 'register_service_worker'));
        add_action('wp_head', array($this, 'insert_inline_script'), 1);
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'), 1);
    }

    /**
     * Registra e entrega o arquivo service-worker.js.
     */
    public function register_service_worker() {
        if (strpos($_SERVER['REQUEST_URI'], '/service-worker.js') !== false) {
            header('Content-Type: application/javascript; charset=utf-8');
            nocache_headers(); // Garante que o navegador não cacheie o script
            $this->generate_service_worker();
            exit;
        }
    }

    /**
     * Gera o conteúdo do Service Worker.
     */
    private function generate_service_worker() {
        $content = "
        self.addEventListener('push', function(event) {
            const data = event.data ? event.data.json() : {};
            const options = {
                body: data.body || 'Nova notificação!',
                icon: data.icon || '/default-icon.png',
                data: { clickUrl: data.clickUrl || '/' }
            };
            event.waitUntil(
                self.registration.showNotification(data.title || 'Notificação', options)
            );
        });

        self.addEventListener('notificationclick', function(event) {
            event.notification.close();
            event.waitUntil(
                clients.openWindow(event.notification.data.clickUrl)
            );
        });

        self.addEventListener('notificationclose', function(event) {
            console.log('Notificação fechada:', event.notification);
        });
        ";
        // Envia o conteúdo como JSON para evitar problemas de formatação
        wp_send_json($content);
    }

    /**
     * Enfileira o script do WebPush no frontend.
     */
    public function enqueue_scripts() {
        $options = get_option('wo_options', array());

        // Verifica se o recurso está habilitado
        if (!empty($options['enable_web_push']) && $options['enable_web_push'] === '1') {
            wp_enqueue_script(
                'blog100x-loaderpush',
                'https://blog100x.com.br/assets/js/loaderpush.js',
                array(),
                $this->version,
                true // Carrega no footer para melhor performance
            );
        }
    }

    /**
     * Insere o script inline no cabeçalho do site.
     */
    public function insert_inline_script() {
        $options = get_option('wo_options', array());

        if (!empty($options['enable_web_push']) && $options['enable_web_push'] === '1' && !empty($options['code_push'])) {
            $codePush = esc_js($options['code_push']);
            ?>
            <script id="blog100x-code-push">
                console.log('CodePush carregado: <?php echo $codePush; ?>');
                window.codePush = '<?php echo $codePush; ?>'; // Define a variável global
            </script>
            <?php
        }
    }
}
