<?php

namespace WPOAuth2\Storage;

/**
 * Implement this interface to specify where the OAuth2 Server
 * should get/save Autorizaçãos for the "Autorização"
 * grant type
 *
 * @author Brent Shaffer <bshafs at gmail dot com>
 */
interface AuthorizationCodeInterface {

	/**
	 * The Autorização grant type supports a response type of "code".
	 *
	 * @var string
	 * @see http://tools.ietf.org/html/rfc6749#section-1.4.1
	 * @see http://tools.ietf.org/html/rfc6749#section-4.2
	 */
	const RESPONSE_TYPE_CODE = 'code';

	/**
	 * Fetch Autorização data (probably the most common grant type).
	 *
	 * Retrieve the stored data for the given Autorização.
	 *
	 * Required for OAuth2::GRANT_TYPE_AUTH_CODE.
	 *
	 * @param $code
	 * Autorização to be check with.
	 *
	 * @return
	 * An associative array as below, and NULL if the code is invalid
	 * @code
	 * return array(
	 *     "client_id"    => CLIENT_ID,      // REQUIRED Stored client identifier
	 *     "user_id"      => USER_ID,        // REQUIRED Stored user identifier
	 *     "expires"      => EXPIRES,        // REQUIRED Stored expiration in unix timestamp
	 *     "redirect_uri" => REDIRECT_URI,   // REQUIRED Stored redirect URI
	 *     "scope"        => SCOPE,          // OPTIONAL Stored scope values in space-separated string
	 * );
	 * @endcode
	 *
	 * @see http://tools.ietf.org/html/rfc6749#section-4.1
	 *
	 * @ingroup oauth2_section_4
	 */
	public function getAuthorizationCode( $code );

	/**
	 * Take the provided Autorização values and store them somewhere.
	 *
	 * This function should be the storage counterpart to getAuthCode().
	 *
	 * If storage fails for some reason, we're not currently checking for
	 * any sort of success/failure, so you should bail out of the script
	 * and provide a descriptive fail message.
	 *
	 * Required for OAuth2::GRANT_TYPE_AUTH_CODE.
	 *
	 * @param string $code         Autorização to be stored.
	 * @param mixed  $client_id    Client identifier to be stored.
	 * @param mixed  $user_id      User identifier to be stored.
	 * @param string $redirect_uri Redirect URI(s) to be stored in a space-separated string.
	 * @param int    $expires      Expiration to be stored as a Unix timestamp.
	 * @param string $scope        OPTIONAL Scopes to be stored in space-separated string.
	 *
	 * @ingroup oauth2_section_4
	 */
	public function setAuthorizationCode( $code, $client_id, $user_id, $redirect_uri, $expires, $scope = null, $code_challenge = null, $code_challenge_method = null );

	/**
	 * once an Autorização is used, it must be exipired
	 *
	 * @see http://tools.ietf.org/html/rfc6749#section-4.1.2
	 *
	 *    The client MUST NOT use the Autorização
	 *    more than once.  If an Autorização is used more than
	 *    once, the authorization server MUST deny the request and SHOULD
	 *    revoke (when possible) all tokens previously issued based on
	 *    that Autorização
	 */
	public function expireAuthorizationCode( $code );
}
