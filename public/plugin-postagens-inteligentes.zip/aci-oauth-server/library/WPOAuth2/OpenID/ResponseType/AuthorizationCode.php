<?php

namespace WPOAuth2\OpenID\ResponseType;

use WPOAuth2\OpenID\Storage\AuthorizationCodeInterface as AuthorizationCodeStorageInterface;
use WPOAuth2\ResponseType\AuthorizationCode as BaseAuthorizationCode;

/**
 *
 * @author Brent Shaffer <bshafs at gmail dot com>
 */
class AuthorizationCode extends BaseAuthorizationCode implements AuthorizationCodeInterface {

	public function __construct( AuthorizationCodeStorageInterface $storage, array $config = array() ) {
		parent::__construct( $storage, $config );
	}

	public function getAuthorizeResponse( $params, $user_id = null ) {

		// build the URL to redirect to
		$result = array( 'query' => array() );

		$params += array(
			'scope'                 => null,
			'state'                 => null,
			'id_token'              => null,
			'code_challenge'        => null,
			'code_challenge_method' => null,
		);

		$result['query']['code'] = $this->createAuthorizationCode( $params['client_id'], $user_id, $params['redirect_uri'], $params['scope'], $params['id_token'], $params['code_challenge'], $params['code_challenge_method'] );

		if ( isset( $params['state'] ) ) {
			$result['query']['state'] = $params['state'];
		}

		return array( $params['redirect_uri'], $result );
	}

	/**
	 * Handle the creation of the Autorização.
	 *
	 * @param $client_id
	 * Client identifier related to the Autorização
	 * @param $user_id
	 * User ID associated with the Autorização
	 * @param $redirect_uri
	 * An absolute URI to which the authorization server will redirect the
	 * user-agent to when the end-user authorization step is completed.
	 * @param $scope
	 * (optional) Scopes to be stored in space-separated string.
	 * @param $id_token
	 * (optional) The OpenID Connect id_token.
	 *
	 * @see     http://tools.ietf.org/html/rfc6749#section-4
	 * @ingroup oauth2_section_4
	 */
	public function createAuthorizationCode( $client_id, $user_id, $redirect_uri, $scope = null, $id_token = null, $code_challenge = null, $code_challenge_method = null ) {
		$code = $this->generateAuthorizationCode();
		$this->storage->setAuthorizationCode( $code, $client_id, $user_id, $redirect_uri, current_time( 'timestamp' ) + $this->config['auth_code_lifetime'], $scope, $id_token, $code_challenge, $code_challenge_method );

		return $code;
	}
}
