<?php
function wo_add_client_page() {
	?>
    <div class="wrap">

        <h2><?php _e( 'Gerar Cliente', 'wp-oauth' ); ?>
            <a class="add-new-h2 "
               href="<?php echo admin_url( 'admin.php?page=wo_manage_clients' ); ?>"
               title="Batch"><?php _e( 'Voltar para Clientes', 'wp-oauth' ); ?></a>
        </h2>

        <hr/>

        <form class="wo-form" action="" method="post">
			
			<?php wp_nonce_field( 'create_client', 'nonce' ); ?>
            <input type="hidden" name="create_client" value="1"/>

            <div class="section group">

                <div class="col span_2_of_6">

                    <label class="checkbox-grid"> Permitidos
						
                        <label> <strong>Autorização</strong>
                            <input type="checkbox" name="grant_types[]"
                                   value="authorization_code" checked/>
                            <small class="description">
                                Permitir acesso para este cliente.
                            </small>
                        </label>

                        

                                                
                    </label>
                </div>

                <div class="col span_4_of_6">
                    <div class="wo-background">

                        <h3><?php _e( 'Informações do Cliente', 'wp-oauth' ); ?></h3>
                        <hr/>

                        <div class="section group">
                            <div class="col span_6_of_6">
                                <label> Client Name
                                    <input class="emuv-input" type="text" name="name"
                                           value="" required/>
                                </label>

                                <div style="margin-top: 2.5em" class="advanced-options">
                                    <h3>Configurações</h3>
                                    <hr/>

                                    <label>
                                        Usuário Atribuído às Credenciais do Cliente
                                        <p class="description">
                                        O tipo de concessão "credenciais do cliente" não possui um ID de usuário associado, dificultando a execução de pontos de extremidade protegidos por uma aplicação. Assim, o cliente terá os mesmos privilégios que o usuário selecionado.
                                        </p>
										<?php
										// $user_id = get_post_meta( $client->ID, 'user_id', true );
										wp_dropdown_users(
											array(
												// 'selected'         => $user_id,
												'name'             => 'user_id',
												'show_option_none' => '--- No User ---',
												'class'            => 'select2',
											)
										);
										?>
                                    </label>

                                    <label> Cliente Scope(s)
                                    <p class="description">
    Você pode restringir os escopos aos seguintes para este cliente. O escopo padrão é <strong>"basic"</strong> e permite o acesso a informações gerais.
</p>
                                        <input class="emuv-input" type="text" name="scope"
                                               value="" placeholder="basic"/>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<?php submit_button( __( 'Gerar Cliente', 'wp-oauth' ) ); ?>

        </form>

    </div>
	
	<?php
}
