<?php
function wo_admin_edit_client_page() {
	if ( ! isset( $_REQUEST['id'] ) ) {
		return;
	}
	
	$message = null;
	if ( isset( $_POST['edit_client'] ) && wp_verify_nonce( $_POST['nonce'], 'edit_client_' . $_POST['edit_client'] ) ) {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		
		$update_client = wo_update_client( $_POST );
		$message       = __( 'Client Updated', 'wp-oauth' );
	}
	
	$client = wo_get_client( intval( $_REQUEST['id'] ) );
	if ( ! $client ) {
		exit( 'Client not found' );
	}
	?>
    <div class="wrap">

        <h2><?php _e( 'Editar Cliente', 'wp-oauth' ); ?>
            <small>( id: <?php echo esc_html( $client->ID ); ?> )</small>
            <a class="add-new-h2 "
               href="<?php echo admin_url( 'admin.php?page=wo_manage_clients' ); ?>"
               title="Batch"><?php _e( 'Voltar para Clientes', 'wp-oauth' ); ?></a>
        </h2>

        <hr/>
		
		<?php if ( ! is_null( $message ) ) : ?>
            <div class="notice notice-success is-dismissible">
                <p><?php echo esc_html( $message ); ?></p>
            </div>
		<?php endif; ?>

        <form class="wo-form" action="" method="post">
			
			<?php wp_nonce_field( 'edit_client_' . $client->ID, 'nonce' ); ?>
            <input type="hidden" name="edit_client" value="<?php echo esc_attr( $client->ID ); ?>"/>
            <input type="hidden" name="post_id" value="<?php echo esc_attr( $client->ID ); ?>"/>

            <div class="section group">

                <div class="col span_2_of_6">

                    <label class="checkbox-grid"> Permitidos
						
                        <hr/>

                        <label> <strong>Autorização</strong>
                            <input type="checkbox" name="grant_types[]"
                                   value="authorization_code"
								<?php
								if ( in_array( 'authorization_code', $client->grant_types ) ) {
									echo ' checked';
								}
								?>
                            />
                            <small class="description">
                            Você autoriza a execução de acesso para realizar postagens?.
                            </small>
                        </label>
                    </label>
                </div>

                <div class="col span_4_of_6">
                    <div class="wo-background">

                        <h3><?php _e( 'Informações do Cliente', 'wp-oauth' ); ?></h3>
                        <hr/>

                        <div class="section group">
                            <div class="col span_6_of_6">
                                <label> Client Name
                                    <input class="emuv-input" type="text" name="name"
                                           value="<?php echo esc_html( $client->post_title ); ?>" required/>
                                </label>
                            
                                <hr/>

                                <label> Client ID
                                    <input class="emuv-input" type="text" name="client_id"
                                           value="<?php echo esc_html( get_post_meta( $client->ID, 'client_id', true ) ); ?>"/>
                                </label>

                                <label> Client Secret
                                    <input class="emuv-input" type="text" name="client_secret"
                                           value="<?php echo esc_html( get_post_meta( $client->ID, 'client_secret', true ) ); ?>"/>
                                </label>

                                <div style="margin-top: 2.5em" class="advanced-options">
                                    <h3>Configurações</h3>
                                    <hr/>

                                    <label>
                                        Usuário Atribuído às Credenciais do Cliente
                                        <p class="description">
                                        O tipo de concessão "credenciais do cliente" não possui um ID de usuário associado, dificultando a execução de pontos de extremidade protegidos por uma aplicação. Assim, o cliente terá os mesmos privilégios que o usuário selecionado.
                                        </p>
										<?php
										$user_id = get_post_meta( $client->ID, 'user_id', true );
										wp_dropdown_users(
											array(
												'selected'         => $user_id,
												'name'             => 'user_id',
												'show_option_none' => '--- No User ---',
												'class'            => 'select2',
											)
										);
										?>
                                    </label>

                                    <label> Cliente Scope(s)
                                    <p class="description">
                                    Defina os escopos de acesso para este cliente: <strong>"basic"</strong> para acesso geral ou <strong>"global"</strong> para acesso mais amplo.
</p>
                                        <input class="emuv-input" type="text" name="scope"
                                               value="<?php echo esc_html( get_post_meta( $client->ID, 'scope', true ) ); ?>"
                                               placeholder="basic"/>
                                    </label>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			
			<?php submit_button( __( 'Atualizar Cliente', 'wp-oauth' ) ); ?>

        </form>

    </div>
	
	<?php
}
