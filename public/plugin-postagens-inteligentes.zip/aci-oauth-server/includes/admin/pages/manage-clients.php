<?php function wo_admin_manage_clients_page() {
	 wp_enqueue_style( 'wo_admin' );
	wp_enqueue_script( 'wo_admin' );
	?>
	<div class="wrap">

		<h2><?php _e( 'Clientes', 'wp-oauth' ); ?>
			<a class="add-new-h2 "
			   href="<?php echo admin_url( 'admin.php?page=wo_add_client' ); ?>"
			   title="Batch"><?php _e( 'Adicionar Novo Cliente', 'wp-oauth' ); ?></a>
		</h2>

		<div class="section group">
			<div class="col span_4_of_6">
				<?php
				$CodeTableList = new WO_Table();
				$CodeTableList->prepare_items();
				$CodeTableList->display();
				?>
			</div>		
		</div>
	</div>
	<?php
}
