<?php
/**
 * Plugin Name: ACI - Modais de Captura
 * Description: Exibe modais (Lead, WhatsApp, Grupo) no front-end com envio de dados via API.
 * Version: 2.2
 * Author: Automações Comerciais Integradas
 */

// Admin - Página de Configurações
add_action('admin_menu', function() {
    add_menu_page('ACI Configurações', 'ACI', 'manage_options', 'wo_settings', 'wo_server_options_page');
});
add_action('admin_init', function() {
    register_setting('wo-options-group', 'wo_options');
});

function wo_server_options_page() {
    $options = get_option('wo_options', []);
    ?>
    <div class="wrap">
        <h2>ACI | Modais de Captura</h2>
        <?php settings_errors(); ?>
        <form method="post" action="options.php">
            <?php settings_fields('wo-options-group'); ?>
            <h3>Configurações Gerais</h3>
            <table class="form-table">
                <tr>
                    <th>Mostrar popups a cada (dias):</th>
                    <td>
                        <input type="number" name="wo_options[popup_interval]" value="<?= esc_attr($options['popup_interval'] ?? '3'); ?>" min="1"/>
                        <p class="description">Intervalo em dias para exibir os modais novamente ao mesmo visitante.</p>
                    </td>
                </tr>
                <tr>
                    <th>GUID (Identificador):</th>
                    <td>
                        <input type="text" name="wo_options[guid]" value="<?= esc_attr($options['guid'] ?? ''); ?>" class="regular-text"/>
                        <p class="description"><strong>Chave de Integração:</strong> Copie do seu painel ACI para ativar o envio de leads. Deixe em branco para desativar os modais.</p>
                    </td>
                </tr>
            </table>

            <h3>Popup Lead (E-mail)</h3>
            <table class="form-table">
                <tr><th>Ativar:</th>
                    <td><input type="checkbox" name="wo_options[enable_lead]" value="1" <?= checked($options['enable_lead'] ?? '', '1', false); ?> /></td></tr>
                <tr><th>Título:</th>
                    <td><input type="text" name="wo_options[lead_title]" value="<?= esc_attr($options['lead_title'] ?? ''); ?>" class="regular-text"/></td></tr>
                <tr><th>Descrição:</th>
                    <td><textarea name="wo_options[lead_description]" class="regular-text" rows="3"><?= esc_textarea($options['lead_description'] ?? ''); ?></textarea></td></tr>
            </table>

            <h3>Popup WhatsApp</h3>
            <table class="form-table">
                <tr><th>Ativar:</th>
                    <td><input type="checkbox" name="wo_options[enable_whatsapp]" value="1" <?= checked($options['enable_whatsapp'] ?? '', '1', false); ?> /></td></tr>
                <tr><th>Link WhatsApp:</th>
                    <td><input type="url" name="wo_options[whatsapp_link]" value="<?= esc_attr($options['whatsapp_link'] ?? ''); ?>" class="regular-text"/></td></tr>
                <tr><th>Título:</th>
                    <td><input type="text" name="wo_options[whatsapp_title]" value="<?= esc_attr($options['whatsapp_title'] ?? ''); ?>" class="regular-text"/></td></tr>
                <tr><th>Descrição:</th>
                    <td><textarea name="wo_options[whatsapp_description]" class="regular-text" rows="3"><?= esc_textarea($options['whatsapp_description'] ?? ''); ?></textarea></td></tr>
            </table>

            <h3>Popup Link de Grupo</h3>
            <table class="form-table">
                <tr><th>Ativar:</th>
                    <td><input type="checkbox" name="wo_options[enable_group]" value="1" <?= checked($options['enable_group'] ?? '', '1', false); ?> /></td></tr>
                <tr><th>Link do Grupo:</th>
                    <td><input type="url" name="wo_options[group_link]" value="<?= esc_attr($options['group_link'] ?? ''); ?>" class="regular-text"/></td></tr>
                <tr><th>Título:</th>
                    <td><input type="text" name="wo_options[group_title]" value="<?= esc_attr($options['group_title'] ?? ''); ?>" class="regular-text"/></td></tr>
                <tr><th>Descrição:</th>
                    <td><textarea name="wo_options[group_description]" class="regular-text" rows="3"><?= esc_textarea($options['group_description'] ?? ''); ?></textarea></td></tr>
            </table>

            <p class="submit"><input type="submit" class="button-primary" value="Salvar Alterações"/></p>
        </form>
    </div>
    <?php
}


// Atualiza o cache_buster sempre que salvar
add_action('update_option_wo_options', function ($old, $new) {
    update_option('aci_cache_buster', time());
}, 10, 2);
