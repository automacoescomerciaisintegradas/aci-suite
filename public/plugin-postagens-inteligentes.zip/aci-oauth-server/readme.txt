=== aci (OAuth Authentication) ===

Contributors: Automações Comerciais Integradas
## Desenvolvido por
Automações Comerciais Integradas! ⚙️ (Canal/Grupo) - contato@automacoescomerciais.com.br

Donate link: https://aci.automacoescomerciais.com.br/ 
Requires at least: 4.7.2
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Adds Authentication through OAuth 2. Provides the ability for Single Sign On for websites & Mobile Applications.

== Description ==

Connect your app to WordPress or use SSO to connect multiple websites with the same username and passwords. No 3rd party servers are needed with aci. Everything you need is in this plugin.

= Features =

* WP REST API Authentication. Provides ability to make authorized calls to protected REST API endpoints.
* WP REST API Lock Down. Prevent any calls to the REST API unless authorized
* Unlimited OAuth 2.0 Clients
* Support for Implicit Flow
* Built-In Resource Server
* Automated Authorization Flow (User does not have to see authorization screen)
* Easily Extend/ Modify the Endpoints
* OAuth 2.0 PKCE
* Modern and Legacy JWT authorization support. OAuth 2.0 JSON Web Token Support

= Supported Grant Types =

* Authentication Code w/Implicit


= Supports =

* Connecting any Custom Mobile and Desktop Application to WordPress's Backend.
* Any software or web platform utilizing OAuth 2.0.
* Allows RocketChat to use WordPress as a Backend.
* Connects Moodle LMS and use WordPress users.
* Alexa Skills Authentication
* Tribe.so Community OAuth 2 SSO Support

= How to Use =

Visit https://aci.automacoescomerciais.com.br/ for detailed documentation on installing, configuring and using
WordPress OAuth Server.

= Licensing = 

aci is free to use. Please support the project by licensing. You can view more information at
https://aci.automacoescomerciais.com.br/.

= Minimum Requirements =

* PHP 5.6.4 or greater *(latest version recommended)*
* OpenSSL installed and enabled if you plan on using OpenID Connect

= Support =

Support requests should be made by opening a support request at https://aci.automacoescomerciais.com.br/.

== Installation ==

1. Upload `oauth-provider` to the `/wp-content/plugins/` directory or use the built in plugin install by WordPress
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Click 'Configurações' and then 'permalinks'. Then simply click 'Save Changes' to flush the rewrite rules so that OAuth2 Provider
1. You're Ready to Rock

== Frequently Asked Questions ==

= Do I need OAuth2 or App Passwords? =
This depends. If you project requires random users access an application, then OAuth2 is the route you need. If you are making
a server that handles a one time client id and secert for authorization, then Application Passwords is for you.

= How do I add a APP/Client? =
Click on `Settings->OAuth Server`. Click on the `Clients` tab and then `Adicionar Novo Cliente`. Enter the Informações do Cliente and your are done.

= Does WordPress OAuth Server Support SSO (Single Sign On) =
Yes, WordPress OAuth Server does support Single Sign On for both Traditional OAuth2 Flow and OpenID Connect.

= Is there support for this plugin? Can you help me? =
You can visit our https://aci.automacoescomerciais.com.br/ to open up a support request directly with developers.

= Can you set this up for me on my current website? =
* DRINKS COFFEE * Can I? "YES". You are more than welcome to contact us with if you should ever need assistance.

= How do I use WordPress OAuth Server? =
You can visit https://aci.automacoescomerciais.com.br/. You will find in-depth documentation as well as examples of how to get started.

== Screenshots ==

1. Adding a Client

== Changelog ==

= 1.0.0 =
* (Security Update) Refactored the "destroy" endpoint to remove the auto redirect in favor for a manual checkpoint.
* Cleaned up misc functions. This should not effect any exsisting implementations.
* Tested with 6.4 installed.


= 1.0.0 =
* INITIAL BUILD