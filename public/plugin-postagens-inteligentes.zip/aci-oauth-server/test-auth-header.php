<?php
/**
 * Arquivo de Teste: Diagnóstico de Header Authorization
 * 
 * INSTRUÇÕES:
 * 1. Faça upload deste arquivo para a raiz do seu WordPress
 * 2. Acesse: https://seu-site.com/test-auth-header.php
 * 3. Ou teste via cURL (veja exemplos abaixo)
 * 
 * IMPORTANTE: Remova este arquivo após o teste por questões de segurança!
 */

// Define o tipo de resposta como JSON
header('Content-Type: application/json; charset=utf-8');

// Função para obter todos os headers de forma compatível
function getAllHeaders() {
    if (function_exists('getallheaders')) {
        return getallheaders();
    }
    
    $headers = [];
    foreach ($_SERVER as $name => $value) {
        if (substr($name, 0, 5) == 'HTTP_') {
            $headers[str_replace(' ', '-', ucwords(strtolower(str_replace('_', ' ', substr($name, 5)))))] = $value;
        }
    }
    return $headers;
}

// Coleta informações
$headers = getAllHeaders();
$serverVars = $_SERVER;

// Tenta extrair credenciais do header Authorization
$authHeader = null;
$extractedUser = null;
$extractedPass = null;

// Tenta várias formas de obter o header Authorization
if (isset($headers['Authorization'])) {
    $authHeader = $headers['Authorization'];
} elseif (isset($serverVars['HTTP_AUTHORIZATION'])) {
    $authHeader = $serverVars['HTTP_AUTHORIZATION'];
} elseif (isset($serverVars['REDIRECT_HTTP_AUTHORIZATION'])) {
    $authHeader = $serverVars['REDIRECT_HTTP_AUTHORIZATION'];
}

// Se encontrou o header, tenta decodificar
if ($authHeader && stripos($authHeader, 'basic') === 0) {
    $encoded = trim(substr($authHeader, 6));
    $decoded = base64_decode($encoded);
    $parts = explode(':', $decoded, 2);
    
    if (count($parts) === 2) {
        $extractedUser = $parts[0];
        $extractedPass = '***' . substr($parts[1], -3); // Mostra apenas os últimos 3 caracteres
    }
}

// Monta a resposta
$response = [
    'status' => 'OK',
    'timestamp' => date('Y-m-d H:i:s'),
    'server_software' => $serverVars['SERVER_SOFTWARE'] ?? 'Desconhecido',
    
    'authorization_header' => [
        'found' => $authHeader !== null,
        'value' => $authHeader ? substr($authHeader, 0, 30) . '...' : 'NÃO ENCONTRADO',
        'source' => $authHeader ? (
            isset($headers['Authorization']) ? 'getallheaders()' : (
                isset($serverVars['HTTP_AUTHORIZATION']) ? '$_SERVER[HTTP_AUTHORIZATION]' : 
                '$_SERVER[REDIRECT_HTTP_AUTHORIZATION]'
            )
        ) : 'Nenhuma fonte',
    ],
    
    'extracted_credentials' => [
        'success' => $extractedUser !== null,
        'username' => $extractedUser ?? 'NÃO EXTRAÍDO',
        'password' => $extractedPass ?? 'NÃO EXTRAÍDO',
    ],
    
    'php_auth_vars' => [
        'PHP_AUTH_USER' => $serverVars['PHP_AUTH_USER'] ?? 'não definido',
        'PHP_AUTH_PW' => isset($serverVars['PHP_AUTH_PW']) ? '***DEFINIDO***' : 'não definido',
    ],
    
    'all_headers' => $headers,
    
    'relevant_server_vars' => [
        'HTTP_AUTHORIZATION' => $serverVars['HTTP_AUTHORIZATION'] ?? 'não definido',
        'REDIRECT_HTTP_AUTHORIZATION' => $serverVars['REDIRECT_HTTP_AUTHORIZATION'] ?? 'não definido',
        'REQUEST_METHOD' => $serverVars['REQUEST_METHOD'] ?? 'não definido',
        'CONTENT_TYPE' => $serverVars['CONTENT_TYPE'] ?? 'não definido',
    ],
    
    'diagnostics' => [
        'can_receive_auth_header' => $authHeader !== null,
        'can_extract_credentials' => $extractedUser !== null,
        'server_type' => (
            stripos($serverVars['SERVER_SOFTWARE'] ?? '', 'nginx') !== false ? 'Nginx' : (
                stripos($serverVars['SERVER_SOFTWARE'] ?? '', 'apache') !== false ? 'Apache' : 
                'Outro'
            )
        ),
        'recommendation' => $authHeader === null ? 
            'O header Authorization NÃO está chegando ao PHP. Configure seu servidor (Nginx/Apache) para passar o header.' :
            ($extractedUser === null ? 
                'O header Authorization foi recebido, mas não pôde ser decodificado. Verifique o formato.' :
                'Tudo OK! O header Authorization está sendo recebido e decodificado corretamente.'
            )
    ],
    
    'test_commands' => [
        'curl_basic_auth' => 'curl -H "Authorization: Basic $(echo -n \'usuario:senha\' | base64)" ' . 
                             'http' . (isset($serverVars['HTTPS']) ? 's' : '') . '://' . 
                             ($serverVars['HTTP_HOST'] ?? 'seu-site.com') . 
                             ($serverVars['REQUEST_URI'] ?? '/test-auth-header.php'),
        
        'curl_with_credentials' => 'curl -u usuario:senha ' . 
                                    'http' . (isset($serverVars['HTTPS']) ? 's' : '') . '://' . 
                                    ($serverVars['HTTP_HOST'] ?? 'seu-site.com') . 
                                    ($serverVars['REQUEST_URI'] ?? '/test-auth-header.php'),
    ]
];

// Retorna a resposta em JSON formatado
echo json_encode($response, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

// Adiciona instruções no final
echo "\n\n/*\n";
echo "=== INSTRUÇÕES DE TESTE ===\n\n";
echo "1. TESTE VIA NAVEGADOR:\n";
echo "   Acesse este arquivo diretamente no navegador.\n";
echo "   Você verá se o servidor está configurado corretamente.\n\n";
echo "2. TESTE VIA cURL (Linux/Mac):\n";
echo "   " . $response['test_commands']['curl_basic_auth'] . "\n\n";
echo "3. TESTE VIA cURL (Windows PowerShell):\n";
echo "   \$auth = [Convert]::ToBase64String([Text.Encoding]::ASCII.GetBytes('usuario:senha'))\n";
echo "   curl -H \"Authorization: Basic \$auth\" " . 
     'http' . (isset($serverVars['HTTPS']) ? 's' : '') . '://' . 
     ($serverVars['HTTP_HOST'] ?? 'seu-site.com') . 
     ($serverVars['REQUEST_URI'] ?? '/test-auth-header.php') . "\n\n";
echo "4. RESULTADO ESPERADO:\n";
echo "   - authorization_header.found: true\n";
echo "   - extracted_credentials.success: true\n";
echo "   - diagnostics.recommendation: 'Tudo OK!'\n\n";
echo "⚠️ IMPORTANTE: Remova este arquivo após o teste!\n";
echo "*/\n";
