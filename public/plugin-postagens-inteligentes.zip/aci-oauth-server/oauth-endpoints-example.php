<?php
/**
 * Exemplo de implementação dos endpoints OAuth2
 * 
 * Este arquivo demonstra como configurar os endpoints de autorização e token
 * para o servidor OAuth2 no WordPress
 */

defined('ABSPATH') or die('No script kiddies please!');

// Inclui as bibliotecas necessárias
require_once dirname(__FILE__) . '/library/WPOAuth2/Autoloader.php';
WPOAuth2\Autoloader::register();

/**
 * Configuração do servidor OAuth2
 */
function setup_oauth_server() {
    // Recupera as configurações
    $settings = wo_setting();
    
    // Cria o storage
    $storage = new WPOAuth2\Storage\Wordpressdb();
    
    // Configuração do servidor
    $config = array(
        'use_crypto_tokens' => false,
        'store_encrypted_token_string' => true,
        'use_openid_connect' => false,
        'issuer' => home_url(null, 'https'),
        'id_lifetime' => 54864000,
        'access_lifetime' => 54864000,
        'refresh_token_lifetime' => 54864000,
        'www_realm' => apply_filters('wo_www_realm', 'Service'),
        'token_param_name' => apply_filters('wo_token_param_name', 'access_token'),
        'token_bearer_header_name' => apply_filters('wo_token_bearer_header_name', 'Bearer'),
        'enforce_state' => wo_setting('enforce_state'),
        'require_exact_redirect_uri' => wo_setting('require_exact_redirect_uri'),
        'allow_implicit' => wo_setting('implicit_enabled'),
        'allow_credentials_in_request_body' => apply_filters('wo_allow_credentials_in_request_body', true),
        'allow_public_clients' => apply_filters('wo_allow_public_clients', true),
        'always_issue_new_refresh_token' => apply_filters('wo_always_issue_new_refresh_token', true),
        'unset_refresh_token_after_use' => apply_filters('wo_unset_refresh_token_after_use', false),
        'redirect_status_code' => apply_filters('wo_redirect_status_code', 302),
        'use_jwt_access_tokens' => true,
    );
    
    // Cria o servidor OAuth2
    $server = new WPOAuth2\Server($storage, $config);
    
    // Adiciona os tipos de concessão (grant types)
    if ('1' == wo_setting('auth_code_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\AuthorizationCode($storage));
    }
    
    if ('1' == wo_setting('client_creds_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\ClientCredentials($storage));
    }
    
    if ('1' == wo_setting('user_creds_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\UserCredentials($storage));
    }
    
    if ('1' == wo_setting('refresh_tokens_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\RefreshToken($storage, $config));
    }
    
    if ('1' == wo_setting('jwt_bearer_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\JwtBearer($storage, site_url()));
    }
    
    // Configura os escopos
    $default_scope = apply_filters('wo_default_scope', 'basic');
    
    $supported_scopes = apply_filters(
        'wo_scopes',
        array(
            'openid',
            'profile',
            'email',
            'basic',
        )
    );
    
    $scope_util = new WPOAuth2\Scope(
        array(
            'default_scope' => $default_scope,
            'supported_scopes' => $supported_scopes,
        )
    );
    
    $server->setScopeUtil($scope_util);
    
    return $server;
}

/**
 * Endpoint para autorização OAuth2
 */
function handle_authorize_request() {
    global $wp_query;
    
    if ($wp_query->get('oauth') !== 'authorize') {
        return;
    }
    
    $server = setup_oauth_server();
    
    $request = WPOAuth2\Request::createFromGlobals();
    $response = new WPOAuth2\Response();
    
    // Valida a requisição de autorização
    if (!$server->validateAuthorizeRequest($request, $response)) {
        $response->send();
        exit;
    }
    
    // Verifica se o usuário está logado
    if (!is_user_logged_in()) {
        $settings = wo_setting();
        if ($settings['home_url_modify']) {
            wp_redirect(wp_login_url(add_query_arg($_GET, home_url('oauth/authorize'))));
        } else {
            wp_redirect(wp_login_url(add_query_arg($_GET, site_url('oauth/authorize'))));
        }
        exit;
    }
    
    // Verifica se o usuário autorizou a aplicação
    $is_authorized = true; // Em uma implementação real, isso seria decidido pelo usuário
    $user_id = get_current_user_id();
    
    // Processa a requisição de autorização
    $server->handleAuthorizeRequest($request, $response, $is_authorized, $user_id);
    $response->send();
    exit;
}

/**
 * Endpoint para emissão de tokens OAuth2
 */
function handle_token_request() {
    global $wp_query;
    
    if ($wp_query->get('oauth') !== 'token') {
        return;
    }
    
    $server = setup_oauth_server();
    
    $request = WPOAuth2\Request::createFromGlobals();
    
    // Processa a requisição de token
    $server->handleTokenRequest($request)->send();
    exit;
}

/**
 * Endpoint para revogação de tokens OAuth2
 */
function handle_revoke_request() {
    global $wp_query;
    
    if ($wp_query->get('oauth') !== 'revoke') {
        return;
    }
    
    $server = setup_oauth_server();
    
    $request = WPOAuth2\Request::createFromGlobals();
    $response = new WPOAuth2\Response();
    
    // Processa a requisição de revogação
    $server->handleRevokeRequest($request, $response);
    $response->send();
    exit;
}

// Registra as funções como hooks
add_action('template_redirect', 'handle_authorize_request');
add_action('template_redirect', 'handle_token_request');
add_action('template_redirect', 'handle_revoke_request');

// Endpoint para informações do usuário
function handle_userinfo_request() {
    global $wp_query;
    
    if ($wp_query->get('oauth') !== 'me') {
        return;
    }
    
    $server = setup_oauth_server();
    
    $request = WPOAuth2\Request::createFromGlobals();
    $response = new WPOAuth2\Response();
    
    // Verifica se o token é válido
    if (!$server->verifyResourceRequest($request)) {
        $server->getResponse()->send();
        exit;
    }
    
    // Recupera os dados do token
    $token = $server->getAccessTokenData($request);
    
    if (!$token) {
        $response->setError(400, 'invalid_request', __('Invalid token', 'wp-oauth'));
        $response->send();
        exit;
    }
    
    // Recupera as informações do usuário
    $user_id = $token['user_id'];
    $user = get_userdata($user_id);
    
    if (!$user) {
        $response->setError(404, 'user_not_found', __('User not found', 'wp-oauth'));
        $response->send();
        exit;
    }
    
    // Retorna as informações do usuário
    $userinfo = array(
        'sub' => $user_id,
        'name' => $user->display_name,
        'email' => $user->user_email,
        'email_verified' => true,
    );
    
    $response = new WPOAuth2\Response($userinfo);
    $response->send();
    exit;
}

add_action('template_redirect', 'handle_userinfo_request');

/**
 * Endpoint para configurações OpenID Connect
 */
function handle_openid_configuration() {
    global $wp_query;
    
    if ($wp_query->get('well-known') !== 'openid-configuration' && 
        $wp_query->get('well-known') !== 'oauth-authorization-server') {
        return;
    }
    
    $openid_discovery_values = apply_filters(
        'wpo_well_known_openid_configuration',
        array(
            'issuer' => home_url(null, 'https'),
            'authorization_endpoint' => home_url('/oauth/authorize/'),
            'token_endpoint' => home_url('/oauth/token/'),
            'userinfo_endpoint' => home_url('/oauth/me/'),
            'end_session_endpoint' => home_url('/oauth/destroy/'),
            'jwks_uri' => home_url('/.well-known/keys/'),
            'revocation_endpoint' => home_url('/oauth/revoke/'),
            'introspection_endpoint' => home_url('/oauth/introspection/'),
            'registration_endpoint' => null,
            'grant_types_supported' => array(
                'authorization_code',
                'client_credentials',
                'refresh_token',
                'user_credentials',
                'implicit',
            ),
            'service_documentation' => null,
            'scopes_supported' => array(
                'openid',
                'profile',
                'email',
                'basic',
            ),
            'response_types_supported' => array(
                'code',
                'id_token',
                'token id_token',
                'code id_token',
            ),
            'subject_types_supported' => array(
                'public',
            ),
            'id_token_signing_alg_values_supported' => array(
                'RS256',
            ),
            'token_endpoint_auth_methods_supported' => array(
                'client_secret_basic',
            ),
        )
    );
    
    $response = new WPOAuth2\Response($openid_discovery_values);
    $response->send();
    exit;
}

add_action('template_redirect', 'handle_openid_configuration');

/**
 * Endpoint para as chaves públicas (JWKS)
 */
function handle_keys_request() {
    global $wp_query;
    
    if ($wp_query->get('well-known') !== 'keys') {
        return;
    }
    
    $keys = wpoauth_get_server_certs();
    $public_key = openssl_pkey_get_public(file_get_contents($keys['public']));
    $public_key = openssl_pkey_get_details($public_key);
    
    $response = new WPOAuth2\Response(
        array(
            'keys' => array(
                array(
                    'kty' => 'RSA',
                    'alg' => 'RS256',
                    'kid' => get_option('wp_oauth_activation_time'),
                    'use' => 'sig',
                    'n' => rtrim(strtr(base64_encode($public_key['rsa']['n']), '+/', '-_'), '='),
                    'e' => base64_encode($public_key['rsa']['e']),
                ),
            ),
        )
    );
    $response->send();
    exit;
}

add_action('template_redirect', 'handle_keys_request');