document.addEventListener('DOMContentLoaded', function () {
    const config = window.ACIModais;
    if (!config || !config.guid || !config.modais || config.modais.length === 0) return;

    const modais = config.modais;
    const guid = config.guid;
    const dias = config.dias || 3;
    let currentModalIndex = 0;

    function diasParaMilissegundos(d) {
        return d * 24 * 60 * 60 * 1000;
    }

    function podeExibirModal(tipo) {
        const key = `aci_modal_${tipo}_${guid}`;
        const ultimo = localStorage.getItem(key);
        if (!ultimo) return true;
        return (Date.now() - parseInt(ultimo, 10)) > diasParaMilissegundos(dias);
    }

    function registrarVisualizacaoModal(tipo) {
        localStorage.setItem(`aci_modal_${tipo}_${guid}`, Date.now().toString());
    }

    function closeModal(id) {
        const modal = document.getElementById(`modal-${id}`);
        if (modal) {
            modal.style.display = 'none';
            document.body.style.overflow = '';
        }
        proximoModal();
    }

    window.closeModal = closeModal;

    function createModal(id, title, description, fieldsHTML, btnText, btnColor, onClickJs) {
        const modal = document.createElement('div');
        modal.id = `modal-${id}`;
        modal.className = 'aci-modal';
        modal.innerHTML = `
            <div class="aci-modal-content">
                <span class="aci-close" onclick="closeModal('${id}')">&times;</span>
                <h2>${title}</h2>
                <p>${description}</p>
                ${fieldsHTML}
                <button class="aci-button" style="background:${btnColor};" onclick="${onClickJs}">${btnText}</button>
            </div>
        `;
        document.body.appendChild(modal);
    }

    function gerarModais() {
        if (modais.includes('lead')) {
            createModal(
                'lead',
                config.lead_title || 'Receba novidades',
                config.lead_desc || 'Cadastre seu e-mail abaixo:',
                `<input type="text" id="name-lead" class="aci-input" placeholder="Seu nome">
                 <input type="email" id="email-lead" class="aci-input" placeholder="Seu e-mail">`,
                'Quero Receber',
                '#28a745',
                `sendData(1, document.getElementById('name-lead').value, document.getElementById('email-lead').value)`
            );
        }

        if (modais.includes('whatsapp')) {
            createModal(
                'whatsapp',
                config.wa_title || 'Fale conosco',
                config.wa_desc || 'Nos chame no WhatsApp:',
                `<input type="text" id="name-whatsapp" class="aci-input" placeholder="Seu nome">
                 <input type="tel" id="whatsapp-whatsapp" class="aci-input" placeholder="(DDD) 90000-0000">`,
                'Falar Agora',
                '#25d366',
                `sendData(2, document.getElementById('name-whatsapp').value, '', document.getElementById('whatsapp-whatsapp').value)`
            );
        }

        if (modais.includes('group')) {
            createModal(
                'group',
                config.group_title || 'Entre no grupo',
                config.group_desc || 'Participe do nosso grupo:',
                ``,
                'Entrar',
                '#007bff',
                `window.open('${config.group_link}', '_blank'); closeModal('group')`
            );
        }
    }

    function abrirModal(id) {
        const modal = document.getElementById(`modal-${id}`);
        if (modal) {
            modal.style.display = 'block';
            document.body.style.overflow = 'hidden';
        }
    }

    function proximoModal() {
        currentModalIndex++;
        while (currentModalIndex < modais.length) {
            const tipo = modais[currentModalIndex];
            if (podeExibirModal(tipo)) {
                abrirModal(tipo);
                registrarVisualizacaoModal(tipo);
                break;
            }
            currentModalIndex++;
        }
    }

    function iniciarSequencia() {
        while (currentModalIndex < modais.length) {
            const tipo = modais[currentModalIndex];
            if (podeExibirModal(tipo)) {
                abrirModal(tipo);
                registrarVisualizacaoModal(tipo);
                break;
            }
            currentModalIndex++;
        }
    }

    gerarModais();
    iniciarSequencia();
});

// Envio de dados
function sendData(tipo, name, email, whatsapp = '') {
    const guid = window.ACIModais?.guid || '';

    // Detecta infos do navegador
    const userAgent = navigator.userAgent;
    const browserInfo = getBrowserInfo(userAgent);
    const os = getOS(userAgent);

    fetch('https://api.automacoescomerciais.com.br/api/Receive/SaveSubscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            Identificador: guid,
            Nome: name,
            Email: email,
            Celular: whatsapp,
            DataCadastro: new Date().toISOString(),
            DataAlteracao: new Date().toISOString(),
            Ativo: true,

            // Novos campos
            OrigemEndpoint: window.location.href,
            Browser: browserInfo.name,
            BrowserVersion: browserInfo.version,
            OS: os,
            IP: '' // Voc pode deixar vazio que o backend pode preencher com base no IP da requisio
        })
    })
        .then(r => {
            if (!r.ok) throw new Error('Erro HTTP: ' + r.status);
            return r.json();
        })
        .then(data => {
            console.log('Enviado com sucesso', data);
            const tipoStr = tipo === 1 ? 'lead' : tipo === 2 ? 'whatsapp' : 'group';
            closeModal(tipoStr);
        })
        .catch(e => console.error('Erro no envio', e));
}


function getBrowserInfo(ua) {
    let tem, M = ua.match(/(opera|chrome|safari|firefox|edge|trident(?=\/))\/?\s*(\d+)/i) || [];
    if (/trident/i.test(M[1])) {
        tem = /\brv[ :]+(\d+)/g.exec(ua) || [];
        return { name: 'IE', version: tem[1] || '' };
    }
    if (M[1] === 'Chrome') {
        tem = ua.match(/\b(OPR|Edge)\/(\d+)/);
        if (tem != null) return { name: tem[1].replace('OPR', 'Opera'), version: tem[2] };
    }
    M = M[2] ? [M[1], M[2]] : [navigator.appName, navigator.appVersion, '-?'];
    tem = ua.match(/version\/(\d+)/i);
    if (tem != null) M.splice(1, 1, tem[1]);
    return { name: M[0], version: M[1] };
}

function getOS(ua) {
    if (ua.indexOf('Win') !== -1) return 'Windows';
    if (ua.indexOf('Mac') !== -1) return 'MacOS';
    if (ua.indexOf('X11') !== -1) return 'UNIX';
    if (ua.indexOf('Linux') !== -1) return 'Linux';
    if (/Android/i.test(ua)) return 'Android';
    if (/iPhone|iPad|iPod/i.test(ua)) return 'iOS';
    return 'Desconhecido';
}