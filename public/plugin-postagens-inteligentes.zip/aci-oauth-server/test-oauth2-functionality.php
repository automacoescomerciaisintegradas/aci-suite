<?php
/**
 * Exemplo de teste para a funcionalidade OAuth2
 * 
 * Este arquivo demonstra como testar os componentes do servidor OAuth2
 */

defined('ABSPATH') or die('No script kiddies please!');

/**
 * Função de teste para verificar se o servidor OAuth2 está configurado corretamente
 */
function test_oauth2_setup() {
    try {
        // Verifica se as tabelas do banco de dados existem
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'oauth_access_tokens',
            $wpdb->prefix . 'oauth_refresh_tokens',
            $wpdb->prefix . 'oauth_authorization_codes',
            $wpdb->prefix . 'oauth_scopes',
            $wpdb->prefix . 'oauth_jwt',
            $wpdb->prefix . 'oauth_public_keys'
        );
        
        $missing_tables = array();
        foreach ($tables as $table) {
            if ($wpdb->get_var("SHOW TABLES LIKE '$table'") !== $table) {
                $missing_tables[] = $table;
            }
        }
        
        if (!empty($missing_tables)) {
            error_log('Tabelas OAuth2 ausentes: ' . implode(', ', $missing_tables));
            return false;
        }
        
        // Verifica se as chaves de criptografia existem
        if (!wp_oauth_has_certificates()) {
            error_log('Certificados OAuth2 não encontrados');
            return false;
        }
        
        // Verifica se o storage está funcionando
        $storage = new WPOAuth2\Storage\Wordpressdb();
        
        if (!$storage) {
            error_log('Falha ao criar instância do storage OAuth2');
            return false;
        }
        
        // Verifica se as configurações estão definidas
        $settings = wo_setting();
        
        if (empty($settings)) {
            error_log('Configurações OAuth2 não encontradas');
            return false;
        }
        
        return true;
    } catch (Exception $e) {
        error_log('Erro ao testar configuração OAuth2: ' . $e->getMessage());
        return false;
    }
}

/**
 * Testa o processo de autorização OAuth2
 */
function test_authorization_flow() {
    try {
        // Este é um teste simulado do fluxo de autorização
        // Em uma implementação real, isso envolveria requisições HTTP reais
        
        $server = setup_oauth_server();
        
        // Verifica se os endpoints estão configurados
        if (!$server->getAuthorizeController()) {
            error_log('Controller de autorização não está configurado');
            return false;
        }
        
        if (!$server->getTokenController()) {
            error_log('Controller de token não está configurado');
            return false;
        }
        
        // Verifica se os tipos de concessão estão configurados
        $grantTypes = $server->getGrantTypes();
        
        if (empty($grantTypes)) {
            error_log('Nenhum tipo de concessão OAuth2 configurado');
        }
        
        return true;
    } catch (Exception $e) {
        error_log('Erro ao testar fluxo de autorização OAuth2: ' . $e->getMessage());
        return false;
    }
}

/**
 * Testa a geração e validação de tokens
 */
function test_token_generation() {
    try {
        $server = setup_oauth_server();
        $storage = new WPOAuth2\Storage\Wordpressdb();
        
        // Testa a geração de um token de acesso
        $access_token = wo_gen_key();
        $client_id = 'test_client';
        $user_id = 1; // ID do usuário de teste
        $expires = time() + 3600; // Expira em 1 hora
        $scope = 'basic';
        
        // Armazena o token de acesso
        $result = $storage->setAccessToken($access_token, $client_id, $user_id, $expires, $scope);
        
        if (!$result) {
            error_log('Falha ao armazenar token de acesso');
            return false;
        }
        
        // Recupera o token de acesso
        $retrieved_token = $storage->getAccessToken($access_token);
        
        if (!$retrieved_token) {
            error_log('Falha ao recuperar token de acesso');
            return false;
        }
        
        if ($retrieved_token['client_id'] !== $client_id) {
            error_log('Cliente do token não corresponde');
            return false;
        }
        
        // Limpa o token de teste
        $storage->unsetAccessToken($access_token);
        
        return true;
    } catch (Exception $e) {
        error_log('Erro ao testar geração de token OAuth2: ' . $e->getMessage());
        return false;
    }
}

/**
 * Testa a validação de credenciais do cliente
 */
function test_client_credentials() {
    try {
        $storage = new WPOAuth2\Storage\Wordpressdb();
        
        // Cria um cliente de teste
        $client_data = array(
            'name' => 'Test Client',
            'user_id' => 1,
            'redirect_uri' => 'http://localhost/callback',
            'grant_types' => array('client_credentials'),
            'scope' => 'basic'
        );
        
        $client_id = wo_insert_client($client_data);
        
        if (!$client_id) {
            error_log('Falha ao criar cliente de teste');
            return false;
        }
        
        // Recupera as credenciais do cliente
        $client_details = $storage->getClientDetails($client_id);
        
        if (!$client_details) {
            error_log('Falha ao recuperar detalhes do cliente');
            return false;
        }
        
        $client_id = $client_details['client_id'];
        $client_secret = $client_details['client_secret'];
        
        // Testa as credenciais do cliente
        $valid_credentials = $storage->checkClientCredentials($client_id, $client_secret);
        
        if (!$valid_credentials) {
            error_log('Credenciais do cliente não são válidas');
            return false;
        }
        
        // Testa se é um cliente público
        $is_public = $storage->isPublicClient($client_id);
        
        if ($is_public) {
            error_log('Cliente de teste não deveria ser público');
        }
        
        // Remove o cliente de teste
        wp_delete_post($client_id, true);
        
        return true;
    } catch (Exception $e) {
        error_log('Erro ao testar credenciais do cliente OAuth2: ' . $e->getMessage());
        return false;
    }
}

/**
 * Testa a funcionalidade completa do OAuth2
 */
function run_oauth2_tests() {
    $results = array();
    
    $results['setup'] = test_oauth2_setup();
    $results['authorization_flow'] = test_authorization_flow();
    $results['token_generation'] = test_token_generation();
    $results['client_credentials'] = test_client_credentials();
    
    // Gera um relatório de testes
    $report = "Relatório de Testes OAuth2:\n";
    $report .= "Configuração do servidor: " . ($results['setup'] ? "OK" : "FALHOU") . "\n";
    $report .= "Fluxo de autorização: " . ($results['authorization_flow'] ? "OK" : "FALHOU") . "\n";
    $report .= "Geração de tokens: " . ($results['token_generation'] ? "OK" : "FALHOU") . "\n";
    $report .= "Credenciais do cliente: " . ($results['client_credentials'] ? "OK" : "FALHOU") . "\n";
    
    // Conta os testes que passaram
    $passed_tests = array_filter($results);
    $report .= "\n" . count($passed_tests) . "/" . count($results) . " testes passaram.\n";
    
    error_log($report);
    
    return $results;
}

// Função auxiliar para setup do servidor (copiada do arquivo anterior)
function setup_oauth_server() {
    $settings = wo_setting();
    $storage = new WPOAuth2\Storage\Wordpressdb();
    
    $config = array(
        'use_crypto_tokens' => false,
        'store_encrypted_token_string' => true,
        'use_openid_connect' => false,
        'issuer' => home_url(null, 'https'),
        'id_lifetime' => 54864000,
        'access_lifetime' => 54864000,
        'refresh_token_lifetime' => 54864000,
        'www_realm' => apply_filters('wo_www_realm', 'Service'),
        'token_param_name' => apply_filters('wo_token_param_name', 'access_token'),
        'token_bearer_header_name' => apply_filters('wo_token_bearer_header_name', 'Bearer'),
        'enforce_state' => wo_setting('enforce_state'),
        'require_exact_redirect_uri' => wo_setting('require_exact_redirect_uri'),
        'allow_implicit' => wo_setting('implicit_enabled'),
        'allow_credentials_in_request_body' => apply_filters('wo_allow_credentials_in_request_body', true),
        'allow_public_clients' => apply_filters('wo_allow_public_clients', true),
        'always_issue_new_refresh_token' => apply_filters('wo_always_issue_new_refresh_token', true),
        'unset_refresh_token_after_use' => apply_filters('wo_unset_refresh_token_after_use', false),
        'redirect_status_code' => apply_filters('wo_redirect_status_code', 302),
        'use_jwt_access_tokens' => true,
    );
    
    $server = new WPOAuth2\Server($storage, $config);
    
    if ('1' == wo_setting('auth_code_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\AuthorizationCode($storage));
    }
    
    if ('1' == wo_setting('client_creds_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\ClientCredentials($storage));
    }
    
    if ('1' == wo_setting('user_creds_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\UserCredentials($storage));
    }
    
    if ('1' == wo_setting('refresh_tokens_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\RefreshToken($storage, $config));
    }
    
    if ('1' == wo_setting('jwt_bearer_enabled')) {
        $server->addGrantType(new WPOAuth2\GrantType\JwtBearer($storage, site_url()));
    }
    
    $default_scope = apply_filters('wo_default_scope', 'basic');
    $supported_scopes = apply_filters(
        'wo_scopes',
        array(
            'openid',
            'profile',
            'email',
            'basic',
        )
    );
    
    $scope_util = new WPOAuth2\Scope(
        array(
            'default_scope' => $default_scope,
            'supported_scopes' => $supported_scopes,
        )
    );
    
    $server->setScopeUtil($scope_util);
    
    return $server;
}

// Executa os testes automaticamente se o arquivo for acessado diretamente em modo de teste
if (defined('WP_TESTS_CONFIG_PATH') || (defined('DOING_AJAX') && DOING_AJAX) || (defined('WP_CLI') && WP_CLI)) {
    run_oauth2_tests();
}