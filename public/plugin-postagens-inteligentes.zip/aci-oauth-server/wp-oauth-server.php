<?php
/**
 * Plugin Name: ACI (OAuth Authentication)
 * Plugin URI: https://aci.automacoescomerciais.com.br
 * Version: 1.0.0
 * Description: Servidor Completo OAuth2 para WordPress. Sistemas de Gerenciamento de Autorização de Usuário para WordPress.
 *
 * @package ACI
 */

defined('ABSPATH') or die('No script kiddies please!');

if (!defined('WPOAUTH_FILE')) define('WPOAUTH_FILE', __FILE__);
if (!defined('WPOAUTH_VERSION')) define('WPOAUTH_VERSION', '1.0.0');

// Traduz o plugin
add_action('plugins_loaded', function () {
	load_plugin_textdomain('wp-oauth', false, dirname(plugin_basename(__FILE__)) . '/languages/');
}, 99);

// ✅ Atualiza timestamp ao salvar configurações dos modais
add_action('update_option_wo_options', function ($old, $new) {
	update_option('aci_cache_buster', time());
}, 10, 2);

// 🔄 Enfileira o CSS global (frontend, admin, login)
function aci_enqueue_global_css() {
	$version = file_exists(plugin_dir_path(__FILE__) . 'assets/css/aci.css')
		? filemtime(plugin_dir_path(__FILE__) . 'assets/css/aci.css')
		: WPOAUTH_VERSION;

	wp_enqueue_style(
		'aci-global',
		plugins_url('assets/css/aci.css', __FILE__),
		[],
		$version
	);
}
add_action('wp_enqueue_scripts', 'aci_enqueue_global_css');
add_action('admin_enqueue_scripts', 'aci_enqueue_global_css');
add_action('login_enqueue_scripts', 'aci_enqueue_global_css');

// ✅ Modais: Enfileira só no front-end e apenas para visitantes
add_action('wp_enqueue_scripts', function () {
	if (is_user_logged_in() && current_user_can('manage_options')) return;
	if (is_admin()) return;

	aci_enqueue_modais_assets();
});

// 🔁 Função que adiciona os modais
function aci_enqueue_modais_assets() {
	$cache_buster = get_option('aci_cache_buster', time());

	wp_enqueue_style(
		'aci-modais',
		plugins_url('assets/css/aci-modais.css', __FILE__),
		[],
		$cache_buster
	);

	wp_enqueue_script(
		'aci-modais-js',
		plugins_url('assets/js/aci-modais.js', __FILE__),
		[],
		$cache_buster,
		true
	);

	$options = get_option('wo_options', []);
	if (!empty($options['guid'])) {
		$modais = [];
		if (!empty($options['enable_lead']))     $modais[] = 'lead';
		if (!empty($options['enable_whatsapp'])) $modais[] = 'whatsapp';
		if (!empty($options['enable_group']))    $modais[] = 'group';

		wp_localize_script('aci-modais-js', 'ACIModais', [
			'guid'         => $options['guid'],
			'dias'         => intval($options['popup_interval'] ?? 3),
			'modais'       => $modais,
			'lead_title'   => $options['lead_title'] ?? '',
			'lead_desc'    => $options['lead_description'] ?? '',
			'wa_title'     => $options['whatsapp_title'] ?? '',
			'wa_desc'      => $options['whatsapp_description'] ?? '',
			'group_title'  => $options['group_title'] ?? '',
			'group_desc'   => $options['group_description'] ?? '',
			'group_link'   => $options['group_link'] ?? '#',
		]);
	}
}

// Admin: Enfileira arquivos internos (Select2, Chosen, etc.)
function wpoauth_server_register_files($suffix) {
	wp_register_script('wo_admin_select2', plugins_url('/assets/js/select2.min.js', __FILE__), ['jquery']);
	wp_register_style('wo_admin_select2', plugins_url('/assets/css/select2.min.css', __FILE__));
	wp_register_script('wo_admin_chosen', plugins_url('/assets/js/chosen.js', __FILE__), ['jquery']);
	wp_register_style('wo_admin', plugins_url('/assets/css/admin.css', __FILE__));
	wp_register_script('wo_admin', plugins_url('/assets/js/admin.js', __FILE__), ['jquery-ui-tabs', 'jquery']);

	if (in_array($suffix, ['toplevel_page_wo_manage_clients', 'admin_page_wo_edit_client', 'oauth-server_page_wo_settings', 'admin_page_wo_add_client'])) {
		wp_enqueue_script('wo_admin_select2');
		wp_enqueue_script('wo_admin_chosen');
		wp_enqueue_style('wo_admin_select2');
		wp_enqueue_script('wo_admin');
		wp_enqueue_style('wo_admin');
	}

	if ($suffix === 'profile.php') {
		wp_enqueue_script('wo_admin');
	}
}
add_action('admin_enqueue_scripts', 'wpoauth_server_register_files');

// Includes
require_once dirname(__FILE__) . '/includes/functions.php';
require_once dirname(__FILE__) . '/includes/cron.php';
require_once dirname(__FILE__) . '/wp-oauth-main.php';

// Reescritas e Query Vars
function wpoauth_server_register_query_vars() {
	_wo_server_register_rewrites();
	global $wp;
	$wp->add_query_var('oauth');
	$wp->add_query_var('well-known');
	$wp->add_query_var('wpoauthincludes');
}
add_action('init', 'wpoauth_server_register_query_vars');

function _wo_server_register_rewrites() {
	add_rewrite_rule('^oauth/(.+)', 'index.php?oauth=$matches[1]', 'top');
	add_rewrite_rule('^.well-known/(.+)', 'index.php?well-known=$matches[1]', 'top');
	add_rewrite_rule('^wpoauthincludes/(.+)', 'index.php?wpoauthincludes=$matches[1]', 'top');
}

// Intercepta templates
function wpoauth_server_template_redirect_intercept($template) {
	global $wp_query;

	if ($wp_query->get('oauth') || $wp_query->get('well-known')) {
		define('DOING_OAUTH', true);
		include_once dirname(__FILE__) . '/library/class-wo-api.php';
		exit;
	}

	return $template;
}
add_filter('template_include', 'wpoauth_server_template_redirect_intercept', 100);

// Ativação
function wpoauth_server_activation($network_wide) {
	if (function_exists('is_multisite') && is_multisite() && $network_wide) {
		$mu_blogs = get_sites();
		foreach ($mu_blogs as $mu_blog) {
			switch_to_blog($mu_blog['blog_id']);
			_wo_server_register_rewrites();
			flush_rewrite_rules();
		}
		restore_current_blog();
	} else {
		_wo_server_register_rewrites();
		flush_rewrite_rules();
	}

	wp_schedule_event(time(), 'hourly', 'wpo_global_cleanup');
}
register_activation_hook(__FILE__, 'wpoauth_server_activation');

// Desativação
function wpoauth_server_deactivation($network_wide) {
	if (function_exists('is_multisite') && is_multisite() && $network_wide) {
		$mu_blogs = get_sites();
		foreach ($mu_blogs as $mu_blog) {
			switch_to_blog($mu_blog['blog_id']);
			flush_rewrite_rules();
		}
		restore_current_blog();
	} else {
		flush_rewrite_rules();
	}

	wp_clear_scheduled_hook('wpo_global_cleanup');
}
register_deactivation_hook(__FILE__, 'wpoauth_server_deactivation');

// Setup do servidor OAuth2
register_activation_hook(__FILE__, [new WO_Server(), 'setup']);
register_activation_hook(__FILE__, [new WO_Server(), 'upgrade']);
