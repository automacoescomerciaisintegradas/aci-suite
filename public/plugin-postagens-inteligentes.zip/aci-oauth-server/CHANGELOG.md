# Changelog - Plugin ACI OAuth2 para WordPress

## [1.0.1] - 2026-01-11

### 🔧 Correções

#### Falha na Autenticação - Issue Resolvida

**Problema:** O servidor recusava as credenciais durante a autenticação OAuth2.

**Causas Identificadas:**
1. Espaços em branco na senha (copiados acidentalmente)
2. Nginx/Easypanel bloqueando o header Authorization
3. Confusão entre senha de login e senha de aplicativo do WordPress

**Soluções Implementadas:**

1. **Remoção Automática de Espaços** ✅
   - Arquivo: `library/WPOAuth2/Storage/Wordpressdb.php`
   - Função: `checkPassword()`
   - Mudança: Adicionado `trim()` para remover espaços em branco da senha
   - Impacto: Resolve automaticamente o problema mais comum de falha de autenticação

2. **Melhor Processamento do Header Authorization** ✅
   - Arquivo: `library/WPOAuth2/Request.php`
   - Função: `getHeadersFromServer()`
   - Mudanças:
     - Adicionado `trim()` no header Authorization
     - Mudado `explode(':', $decoded)` para `explode(':', $decoded, 2)` para suportar senhas com ":"
     - Adicionado tratamento de espaços extras no encoding Base64
   - Impacto: Melhora a robustez do processamento de credenciais

3. **Sistema de Logs de Debug** ✅
   - Arquivos modificados:
     - `library/WPOAuth2/Storage/Wordpressdb.php`
     - `library/WPOAuth2/Request.php`
   - Funcionalidade: Logs detalhados quando `WP_DEBUG` está ativo
   - Informações registradas:
     - Header Authorization recebido
     - Usuário extraído
     - Comprimento da senha
     - Tentativas de login
     - Sucessos e falhas de autenticação
   - Impacto: Facilita o diagnóstico de problemas

### 📚 Documentação

1. **Guia de Solução de Problemas** ✅
   - Arquivo: `SOLUCAO-AUTENTICACAO.md`
   - Conteúdo:
     - Explicação detalhada do problema
     - Soluções passo a passo
     - Configurações para Nginx/Apache/Easypanel
     - Diferença entre senha de login e senha de aplicativo
     - Exemplos de teste com cURL
     - Checklist de resolução

2. **Arquivo de Teste de Diagnóstico** ✅
   - Arquivo: `test-auth-header.php`
   - Funcionalidade:
     - Verifica se o header Authorization está chegando ao servidor
     - Extrai e valida credenciais
     - Fornece diagnóstico automático
     - Inclui exemplos de comandos cURL
   - Uso: Upload para raiz do WordPress e acesso via navegador ou cURL

3. **README Atualizado** ✅
   - Arquivo: `README.md`
   - Adicionado:
     - Seção de solução de problemas de autenticação
     - Link para o guia detalhado
     - Instruções de teste rápido
     - Informações sobre logs de debug

### 🔍 Detalhes Técnicos

#### Mudanças no Código

**library/WPOAuth2/Storage/Wordpressdb.php - checkPassword()**
```php
// ANTES
protected function checkPassword( $user, $password ) {
    $login_check = wp_check_password( $password, $user['user_pass'], $user['ID'] );
    if ( ! $login_check ) {
        do_action( 'wp_login_failed', $user['user_login'] );
    }
    return $login_check;
}

// DEPOIS
protected function checkPassword( $user, $password ) {
    // Remove espaços em branco da senha
    $password = trim( $password );
    
    // Logs de debug
    if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
        error_log( '[ACI OAuth] Tentativa de login para usuário: ' . $user['user_login'] );
        error_log( '[ACI OAuth] Comprimento da senha recebida: ' . strlen( $password ) );
    }
    
    $login_check = wp_check_password( $password, $user['user_pass'], $user['ID'] );
    
    if ( ! $login_check ) {
        do_action( 'wp_login_failed', $user['user_login'] );
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[ACI OAuth] Falha na autenticação para: ' . $user['user_login'] );
        }
    } else {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[ACI OAuth] Autenticação bem-sucedida para: ' . $user['user_login'] );
        }
    }
    
    return $login_check;
}
```

**library/WPOAuth2/Request.php - getHeadersFromServer()**
```php
// ANTES
$exploded = explode( ':', base64_decode( substr( $authorizationHeader, 6 ) ) );

// DEPOIS
$encoded = trim( substr( $authorizationHeader, 6 ) );
$decoded = base64_decode( $encoded );
$exploded = explode( ':', $decoded, 2 ); // Limita a 2 partes
```

### 🎯 Impacto

- **Usuários afetados:** Todos que usam autenticação OAuth2 com senha
- **Compatibilidade:** Totalmente retrocompatível
- **Performance:** Impacto mínimo (apenas trim() adicional)
- **Segurança:** Melhorada (logs apenas em modo debug)

### 📋 Checklist de Teste

- [x] Teste com senha contendo espaços
- [x] Teste com senha sem espaços
- [x] Teste com senha contendo ":"
- [x] Teste em servidor Nginx
- [x] Teste em servidor Apache
- [x] Verificação de logs de debug
- [x] Teste do arquivo de diagnóstico
- [x] Documentação completa

### 🔗 Links Úteis

- [Guia de Solução](SOLUCAO-AUTENTICACAO.md)
- [Arquivo de Teste](test-auth-header.php)
- [README](README.md)

---

## [1.0.0] - 2026-01-11

### 🎉 Lançamento Inicial

- Implementação completa do servidor OAuth2
- Suporte a múltiplos grant types
- Interface de administração
- Integração com WordPress
- Suporte a JWT
- Endpoints OpenID Connect

---

**Desenvolvido por:** Automações Comerciais Integradas  
**Email:** contato@automacoescomerciais.com.br  
**Site:** https://aci.automacoescomerciais.com.br
