<?php
/**
 * Uninstall Plugin
 *
 * @package ACI
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

global $wpdb;

// Drop tables
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_access_tokens" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_refresh_tokens" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_authorization_codes" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_scopes" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_jwt" );
$wpdb->query( "DROP TABLE IF EXISTS {$wpdb->prefix}oauth_public_keys" );

// Delete options
delete_option( 'wo_options' );
delete_option( 'wpoauth_version' );
delete_option( 'wp_oauth_server_db_version' );
delete_option( 'aci_cache_buster' );
